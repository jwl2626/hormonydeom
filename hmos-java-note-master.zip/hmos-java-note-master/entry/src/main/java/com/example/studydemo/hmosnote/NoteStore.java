package com.example.studydemo.hmosnote;

import ohos.data.orm.OrmDatabase;
import ohos.data.orm.annotation.Database;

@Database(entities = {NoteBean.class}, version = 1)
public abstract class NoteStore extends OrmDatabase {
}
