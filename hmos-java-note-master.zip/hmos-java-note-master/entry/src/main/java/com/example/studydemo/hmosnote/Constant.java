package com.example.studydemo.hmosnote;

public class Constant {
    public static String DB_NAME="note_demo";

}
