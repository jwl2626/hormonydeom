package com.example.studydemo.hmosnote;

import ohos.agp.window.dialog.ToastDialog;
import ohos.app.Context;
import ohos.data.DatabaseHelper;
import ohos.data.orm.AllChangeToTarget;
import ohos.data.orm.OrmContext;
import ohos.data.orm.OrmObjectObserver;
import ohos.data.orm.OrmPredicates;
import ohos.hiviewdfx.HiLog;
import ohos.hiviewdfx.HiLogLabel;

import java.util.List;

public class DBUtils {
    private static final HiLogLabel LABEL_LOG = new HiLogLabel(3, 0xD000F00, "OrmContextSlice");
    private DatabaseHelper helper;
    private static DBUtils dbUtils;
    private static Context mContext;

    private void initRegisters() {
        OrmContext ormContext = helper.getOrmContext("note_deom", "note_deom.db", NoteStore.class);
        ormContext.registerEntityObserver("note", entityOrmObjectObserver);
        ormContext.registerStoreObserver("note_deom", storeOrmObjectObserver);
        ormContext.close();
    }

    public static DBUtils getInstance(Context context) {
        mContext = context;
        if (dbUtils == null)
            dbUtils = new DBUtils();
        return dbUtils;
    }

    public DBUtils() {
        helper = new DatabaseHelper(mContext);
        initRegisters();
    }

    private final OrmObjectObserver entityOrmObjectObserver = (changeContext, subAllChange) ->
            HiLog.info(LABEL_LOG, "onChange Entity " +
                    " ,insert row=" + subAllChange.getInsertedList().size() +
                    " ,delete row=" + subAllChange.getDeletedList().size() +
                    " ,update row=" + subAllChange.getUpdatedList().size());

    private final OrmObjectObserver storeOrmObjectObserver = (changeContext, subAllChange) ->
            HiLog.info(LABEL_LOG, "onChange Store");

    private final OrmObjectObserver contextOrmObjectObserver = new OrmObjectObserver() {
        @Override
        public void onChange(OrmContext changeContext, AllChangeToTarget subAllChange) {
            HiLog.info(LABEL_LOG, "onChange Context");
        }
    };

    private final OrmObjectObserver objectOrmObjectObserver = new OrmObjectObserver() {
        @Override
        public void onChange(OrmContext changeContext, AllChangeToTarget subAllChange) {
            HiLog.info(LABEL_LOG, "onChange Object");
        }
    };

    public void unRegisters() {
        OrmContext ormContext = helper.getOrmContext("note_deom", "note_deom.db", NoteStore.class);
        ormContext.unregisterEntityObserver("note", entityOrmObjectObserver);
        ormContext.unregisterStoreObserver("note_deom", storeOrmObjectObserver);
        ormContext.unregisterContextObserver(ormContext, contextOrmObjectObserver);
        ormContext.close();
    }

    public void insert(NoteBean noteBean) {
        OrmContext ormContext = helper.getOrmContext("note_deom", "note_demo.db", NoteStore.class);
        if (ormContext.insert(noteBean)) {
            showToast("操作成功");
        } else {
            showToast("操作失败");
        }
        ormContext.registerContextObserver(ormContext, contextOrmObjectObserver);
        ormContext.flush();
        ormContext.close();
    }

    public void update(NoteBean noteBean) {
        OrmContext ormContext = helper.getOrmContext("note_deom", "note_demo.db", NoteStore.class);
        if (ormContext.update(noteBean)) {
            showToast("操作成功");
        } else {
            showToast("操作失败");
        }
        ormContext.registerContextObserver(ormContext, contextOrmObjectObserver);
        ormContext.flush();
        ormContext.close();
    }

    public void deleteNote(NoteBean noteBean) {
        OrmContext ormContext = helper.getOrmContext("note_demo", "note_demo.db", NoteStore.class);
        if (ormContext.delete(noteBean)) {
            showToast("操作成功");
        } else {
            showToast("操作失败");
        }
        ormContext.flush();
        ormContext.close();
    }

    /**
     * 查询
     *
     * @param keyWord   关键字
     * @param orderType 排序类型 1 创建日期 2 编辑日期 3 标题
     */
    public List<NoteBean> query(String keyWord, int orderType) {
        OrmContext ormContext = helper.getOrmContext("note_demo", "note_demo.db", NoteStore.class);
        OrmPredicates ormPredicates = ormContext.where(NoteBean.class);
        if (keyWord != null && keyWord.length() > 0) {
            ormPredicates = ormPredicates.like("title", String.format("%%%s%%",keyWord)).or().like("content", String.format("%%%s%%",keyWord));
        }
        if (orderType == 1) {
            ormPredicates.orderByDesc("addTime");
        }
        if (orderType == 2) {
            ormPredicates.orderByDesc("updateTime");
        }
        if (orderType == 3) {
            ormPredicates.orderByAsc("title");
        }
        List<NoteBean> query = ormContext.query(ormPredicates);
        HiLog.info(LABEL_LOG, query.size() + "");
        return query;
    }

    public void showToast(String content) {
        ToastDialog toastDialog = new ToastDialog(mContext);
        toastDialog.setText(content).setAlignment(1).show();
    }
}
