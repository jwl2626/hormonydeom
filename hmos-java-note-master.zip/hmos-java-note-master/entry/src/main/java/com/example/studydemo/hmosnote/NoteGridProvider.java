package com.example.studydemo.hmosnote;

import ohos.aafwk.ability.AbilitySlice;
import ohos.agp.components.*;

import java.util.ArrayList;
import java.util.List;

public class NoteGridProvider extends BaseItemProvider {
    private List<NoteBean> mList = new ArrayList<>();
    private AbilitySlice slice;

    public NoteGridProvider(List<NoteBean> list, AbilitySlice slice) {
        this.mList = list;
        this.slice = slice;
    }

    public class MyHolder {
        private Text tvTitle;
        private Text tvContent;
        private Text tvTime;

        public MyHolder(Component component) {
            tvTitle = (Text) component.findComponentById(ResourceTable.Id_tv_title);
            tvContent = (Text) component.findComponentById(ResourceTable.Id_tv_content);
            tvTime = (Text) component.findComponentById(ResourceTable.Id_tv_time);
        }
    }

    @Override
    public int getCount() {
        return mList.size();
    }

    @Override
    public NoteBean getItem(int i) {
        return mList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return (long) mList.get(i).getId();
    }

    @Override
    public Component getComponent(int i, Component component, ComponentContainer componentContainer) {
        final Component cpt;
        MyHolder myHolder;
        if (component == null) {
            cpt = LayoutScatter.getInstance(slice).parse(ResourceTable.Layout_grid_item_note, null, false);
            myHolder = new MyHolder(cpt);
            cpt.setTag(myHolder);
        } else {
            cpt = component;
            myHolder = (MyHolder) cpt.getTag();
        }

        NoteBean noteBean = mList.get(i);
        myHolder.tvTitle.setText(noteBean.getTitle());
        myHolder.tvContent.setText(noteBean.getContent());
        myHolder.tvTime.setText(noteBean.getAddTime());
        ComponentContainer.LayoutConfig layoutConfig = cpt.getLayoutConfig();
        layoutConfig.width = ScreenUtils.getWindowWidthPx(slice) / 3-2*layoutConfig.getMarginLeft();
        cpt.setLayoutConfig(layoutConfig);
        return cpt;
    }

    public void update(List<NoteBean> data) {
        //这里不能用赋值的，必须要用增加的过程，不然不会更新UI,神坑啊啊啊啊啊啊啊啊
        mList.clear();
        mList.addAll(data);
        System.out.println("数量" + data.size());
        notifyDataChanged();
    }
}
