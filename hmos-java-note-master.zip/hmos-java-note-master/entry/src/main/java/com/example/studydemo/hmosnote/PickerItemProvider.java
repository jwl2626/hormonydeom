package com.example.studydemo.hmosnote;

import ohos.aafwk.ability.AbilitySlice;
import ohos.agp.components.*;

import java.util.ArrayList;
import java.util.List;

public class PickerItemProvider extends BaseItemProvider {
    private List<String> list = new ArrayList<>();
    private AbilitySlice abilitySlice;

    public PickerItemProvider(List<String> list, AbilitySlice abilitySlice) {
        this.list = list;
        this.abilitySlice = abilitySlice;
    }

    @Override
    public int getCount() {
        return this.list.size();
    }

    @Override
    public Object getItem(int i) {
        return this.list.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    public class MyHolder {
        private Text tvContent;

        public MyHolder(Component component) {
            tvContent = (Text) component.findComponentById(ResourceTable.Id_tv_content);
        }
    }

    @Override
    public Component getComponent(int i, Component component, ComponentContainer componentContainer) {
        final Component cpt;
        MyHolder myHolder;
        if (component == null) {
            cpt = LayoutScatter.getInstance(abilitySlice).parse(ResourceTable.Layout_item_picker, null, false);
            myHolder = new MyHolder(cpt);
            cpt.setTag(myHolder);
        } else {
            cpt = component;
            myHolder = (MyHolder) cpt.getTag();
        }
        myHolder.tvContent.setText(list.get(i));
        return cpt;
    }
}
