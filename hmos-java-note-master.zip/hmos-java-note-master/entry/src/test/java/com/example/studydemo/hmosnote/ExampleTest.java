package com.example.studydemo.hmosnote;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void onStart() {
    }
}
